package com.brainsecret;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrainSecretApplicationTests {

	@Test
	void contextLoads() {
	}

}
