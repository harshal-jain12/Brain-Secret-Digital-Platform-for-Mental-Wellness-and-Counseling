package com.brainsecret.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class WebSecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .cors().and()  // Enable Cross-Origin Requests
            .csrf().disable() // Disable CSRF (if not using authentication)
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/contact/**").permitAll() // Allow public access to ContactUs API
                .requestMatchers("/api/contact/**", "/api/appointments/**", "/api/sleep/**").permitAll() // Allow public access to ContactUs & Appointments APIs
                .anyRequest().authenticated()
            );
        return http.build();
    }
}
