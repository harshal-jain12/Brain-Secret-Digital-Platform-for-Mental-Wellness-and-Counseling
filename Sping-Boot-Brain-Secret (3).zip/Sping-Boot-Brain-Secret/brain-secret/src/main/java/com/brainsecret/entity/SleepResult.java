package com.brainsecret.entity;

import jakarta.persistence.*;
import java.time.LocalTime;

@Entity
@Table(name = "sleep_results")
public class SleepResult {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int userId;

    private LocalTime sleepTime;
    private LocalTime wakeTime;
    private int disturbances;
    private String sleepQuality;
    
    @Version  // Add this line for optimistic locking
    private int version;  // Hibernate will check version before update

    // Getters and Setters
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public LocalTime getSleepTime() { return sleepTime; }
    public void setSleepTime(LocalTime sleepTime) { this.sleepTime = sleepTime; }

    public LocalTime getWakeTime() { return wakeTime; }
    public void setWakeTime(LocalTime wakeTime) { this.wakeTime = wakeTime; }

    public int getDisturbances() { return disturbances; }
    public void setDisturbances(int disturbances) { this.disturbances = disturbances; }

    public String getSleepQuality() { return sleepQuality; }
    public void setSleepQuality(String sleepQuality) { this.sleepQuality = sleepQuality; }
}
