package com.brainsecret.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.brainsecret.entity.SleepResult;

public interface SleepRepository extends JpaRepository<SleepResult, Integer> {
}


