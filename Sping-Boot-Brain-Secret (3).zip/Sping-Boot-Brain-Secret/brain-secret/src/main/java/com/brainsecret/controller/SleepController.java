package com.brainsecret.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.brainsecret.entity.SleepInput;
import com.brainsecret.entity.SleepResult;
import com.brainsecret.service.SleepService;

@RestController
@RequestMapping("/api/sleep")
@CrossOrigin(origins = "http://localhost:3000")  // Allow React frontend
public class SleepController {
    private final SleepService sleepService;

    public SleepController(SleepService sleepService) {
        this.sleepService = sleepService;
    }

    // Create Sleep Record
    @PostMapping("/{userId}")
    public ResponseEntity<SleepResult> checkSleepQuality(@PathVariable int userId, @RequestBody SleepInput sleepInput) {
        SleepResult result = sleepService.analyzeSleep(userId, sleepInput);
        return ResponseEntity.ok(result);
    }

    // Get All Sleep Records
    @GetMapping("/all")
    public ResponseEntity<List<SleepResult>> getAllSleepRecords() {
        List<SleepResult> records = sleepService.getAllSleepRecords();
        return ResponseEntity.ok(records);
    }

    // Get Sleep Record by ID
    @GetMapping("/{userId}")
    public ResponseEntity<SleepResult> getSleepRecordById(@PathVariable int userId) {
        SleepResult result = sleepService.getSleepRecordById(userId);
        return result != null ? ResponseEntity.ok(result) : ResponseEntity.notFound().build();
    }

    // Update Sleep Record
    @PutMapping("/{userId}")
    public ResponseEntity<SleepResult> updateSleepRecord(@PathVariable int userId, @RequestBody SleepInput sleepInput) {
        SleepResult updatedRecord = sleepService.updateSleepRecord(userId, sleepInput);
        return updatedRecord != null ? ResponseEntity.ok(updatedRecord) : ResponseEntity.notFound().build();
    }

    // Delete Sleep Record
    @DeleteMapping("/{userId}")
    public ResponseEntity<String> deleteSleepRecord(@PathVariable int userId) {
        boolean deleted = sleepService.deleteSleepRecord(userId);
        return deleted ? ResponseEntity.ok("Sleep record deleted successfully.") : ResponseEntity.notFound().build();
    }
}
