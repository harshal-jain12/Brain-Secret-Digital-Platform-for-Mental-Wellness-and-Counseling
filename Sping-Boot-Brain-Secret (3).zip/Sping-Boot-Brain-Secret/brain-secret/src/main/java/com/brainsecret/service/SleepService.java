package com.brainsecret.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import com.brainsecret.entity.SleepInput;
import com.brainsecret.entity.SleepResult;
import com.brainsecret.repository.SleepRepository;

import jakarta.transaction.Transactional;

@Service
public class SleepService {
    
    private final SleepRepository sleepRepository;

    public SleepService(SleepRepository sleepRepository) {
        this.sleepRepository = sleepRepository;
    }

    // Create Sleep Record
   
    public SleepResult analyzeSleep(int userId, SleepInput sleepInput) {
        SleepResult result = new SleepResult();
        result.setUserId(userId);
        result.setSleepTime(sleepInput.getSleepTime());
        result.setWakeTime(sleepInput.getWakeTime());
        result.setDisturbances(sleepInput.getDisturbances());
        result.setSleepQuality("Good"); // Placeholder logic
        return sleepRepository.save(result);
    }

    // Get All Sleep Records
    public List<SleepResult> getAllSleepRecords() {
        return sleepRepository.findAll();
    }

    // Get Sleep Record by ID
    public SleepResult getSleepRecordById(int userId) {
        return sleepRepository.findById(userId).orElse(null);
    }

    // Update Sleep Record
    @Transactional
    public SleepResult updateSleepRecord(int userId, SleepInput sleepInput) {
        Optional<SleepResult> existingRecord = sleepRepository.findById(userId);
        if (existingRecord.isPresent()) {
            SleepResult record = existingRecord.get();
            record.setSleepTime(sleepInput.getSleepTime());
            record.setWakeTime(sleepInput.getWakeTime());
            record.setDisturbances(sleepInput.getDisturbances());
            record.setSleepQuality("Updated Quality");
            return sleepRepository.save(record);
        }
        return null;
    }

    // Delete Sleep Record
    @Transactional
    public boolean deleteSleepRecord(int userId) {
        Optional<SleepResult> existingRecord = sleepRepository.findById(userId);
        if (existingRecord.isPresent()) {
            sleepRepository.deleteById(userId);
            return true;
        }
        return false;
    }
}
